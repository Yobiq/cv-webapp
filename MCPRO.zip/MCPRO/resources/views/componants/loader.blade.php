<!-- loader here -->
<div id="loading-div" class="d-none">
    <div id="spinner-container">
        <div id="loading-spinner"></div>
    </div>
</div>
