@extends('app')
@section('content')
    @include('componants.hero')
@endsection
