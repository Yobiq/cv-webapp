@extends('app')
@section('content')
    @include('componants.contact-form')
@endsection
