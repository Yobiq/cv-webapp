@extends('app')
@section('content')
    @include('componants.project-list')
    
@endsection
