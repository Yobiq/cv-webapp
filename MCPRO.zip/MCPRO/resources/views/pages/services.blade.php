@extends('app')
@section('content')
    <div class="container py-5">
        @include('componants.services')
    </div>
@endsection 