@extends('app')

@section('content')
    @include('componants.about')
@endsection
