

<?php $__env->startSection('content'); ?>
    <?php echo $__env->make('componants.about', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\musab\MCPRO\resources\views/pages/about.blade.php ENDPATH**/ ?>