<!-- loader here -->
<div id="loading-div" class="d-none">
    <div id="spinner-container">
        <div id="loading-spinner"></div>
    </div>
</div>
<?php /**PATH C:\Users\musab\MCPRO\resources\views/componants/loader.blade.php ENDPATH**/ ?>