
<?php $__env->startSection('content'); ?>
    <div class="container py-5">
        <?php echo $__env->make('componants.services', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
    </div>
<?php $__env->stopSection(); ?> 
<?php echo $__env->make('app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\musab\MCPRO\resources\views/pages/services.blade.php ENDPATH**/ ?>